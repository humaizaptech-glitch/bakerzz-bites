/* Data store (JSON). Kept as a JS file so it also works when opened directly from disk (file://). A pure copy lives in data/products.json */
var BAKERZ_DATA = {
  "products": [
    {"id":1,"name":"Belgian Chocolate Berry Cake","category":"cakes","price":32,"rating":4.9,"img":"images/cake.jpg","desc":"Three moist layers of dark chocolate sponge with silky ganache, crowned with fresh berries.","ingredients":["Belgian dark chocolate","Real butter","Fresh cream","Unbleached flour","Free-range eggs","Fresh berries"],"spec":{"Weight":"1.5 kg","Serves":"10-12","Shelf life":"3 days refrigerated"}},

    {"id":2,"name":"Vanilla Bean Celebration Cake","category":"cakes","price":28,"rating":4.7,"img":"images/hero.jpg","desc":"Light vanilla sponge layered with Madagascar vanilla buttercream and chocolate drip.","ingredients":["Madagascar vanilla","Real butter","Unbleached flour","Cane sugar","Milk"],"spec":{"Weight":"1.2 kg","Serves":"8-10","Shelf life":"3 days refrigerated"}},

    {"id":3,"name":"Red Velvet Slice","category":"cakes","price":6,"rating":4.6,"img":"images/Red.123.jpg","desc":"Classic velvety cocoa sponge with tangy cream cheese frosting.","ingredients":["Cocoa","Buttermilk","Cream cheese","Unbleached flour","Butter"],"spec":{"Weight":"150 g","Serves":"1","Shelf life":"2 days"}},



    
    {"id":4,"name":"Butter Croissant","category":"pastries","price":3.5,"rating":4.8,"img":"images/Pastries.1.png","desc":"Flaky, golden, 27-layer French croissant made with cultured butter.","ingredients":["Cultured butter","Unbleached flour","Milk","Yeast","Sea salt"],"spec":{"Weight":"90 g","Serves":"1","Shelf life":"1 day"}},

    {"id":5,"name":"Chocolate Éclair","category":"pastries","price":8.5,"rating":4.8,"img":"images/Pastreis.2.jpg","desc":"Light choux pastry filled with creamy custard and topped with chocolate glaze.","ingredients":["Butter","Vanilla custard","Raspberries","Blueberries","Unbleached flour"],"spec":{"Weight":"110 g","Serves":"1","Shelf life":"1 day"}},
    
    {"id":106,"name":"Cinnamon Roll","category":"pastries","price":8.5,"rating":4.8,"img":"images/Pastries.3.jpg","desc":"Soft, fluffy roll swirled with cinnamon sugar and finished with sweet icing.","ingredients":["Butter","Vanilla custard","Raspberries","Blueberries","Unbleached flour"],"spec":{"Weight":"110 g","Serves":"1","Shelf life":"1 day"}},
    
    {"id":6,"name":"Peach Cream Danish","category":"pastries","price":4.25,"rating":4.5,"img":"images/pastry.jpg","desc":"Sweet peach slices nestled on cream cheese filling with a sugar glaze.","ingredients":["Peaches","Cream cheese","Butter","Unbleached flour","Icing sugar"],"spec":{"Weight":"110 g","Serves":"1","Shelf life":"1 day"}},

      {"id":107,"name":"Almond Croissant","category":"pastries","price":8.5,"rating":4.8,"img":"images/Pastries.4.jpg","desc":"Crispy, buttery croissant filled with almond cream and topped with sliced almonds.","ingredients":["Butter","Vanilla custard","Raspberries","Blueberries","Unbleached flour"],"spec":{"Weight":"110 g","Serves":"1","Shelf life":"1 day"}},

      {"id":108,"name":"Blueberry Danish","category":"pastries","price":8.5,"rating":4.8,"img":"images/Pastries.5.jpg","desc":"Golden Danish pastry filled with creamy custard and juicy blueberries.","ingredients":["Butter","Vanilla custard","Raspberries","Blueberries","Unbleached flour"],"spec":{"Weight":"110 g","Serves":"1","Shelf life":"1 day"}},











    {"id":701,"name":"Chocolate Chip Cookie","category":"cookies","price":2.5,"rating":4.9,"img":"images/Cookies.1.jpg","desc":"Crispy edges, chewy centre and loaded with dark chocolate chips.","ingredients":["Dark chocolate chips","Brown sugar","Real butter","Unbleached flour","Vanilla"],"spec":{"Weight":"70 g","Pack":"Single","Shelf life":"7 days"}},
    
    {"id":702,"name":"Cookie Box (12 pcs)","category":"cookies","price":24,"rating":4.8,"img":"images/Cookies.2.jpg","desc":"An assorted box of our best-selling cookies — perfect for gifting.","ingredients":["Butter","Chocolate","Oats","Nuts","Unbleached flour"],"spec":{"Weight":"840 g","Pack":"12 cookies","Shelf life":"10 days"}},
    
      
        {"id":704,"name":"Red Velvet Cookie","category":"cookies","price":824,"rating":4.8,"img":"images/Cookies.3.jpg","desc":"Soft red velvet cookie with white chocolate chips and a hint of vanilla.","ingredients":["Butter","Chocolate","Oats","Nuts","Unbleached flour"],"spec":{"Weight":"840 g","Pack":"12 cookies","Shelf life":"10 days"}},

          {"id":705,"name":"Peanut Butter Cookie","category":"cookies","price":724,"rating":4.8,"img":"images/Cookies.4.jpg","desc":"A buttery, nutty cookie with a soft center and a classic peanut butter flavor.","ingredients":["Butter","Chocolate","Oats","Nuts","Unbleached flour"],"spec":{"Weight":"840 g","Pack":"12 cookies","Shelf life":"10 days"}},

               {"id":706,"name":"White Chocolate Macadamia Cookie","category":"cookies","price":240,"rating":4.8,"img":"images/Cookies.5.jpg","desc":"A buttery cookie filled with creamy white chocolate chips and crunchy macadamia nuts.","ingredients":["Butter","Chocolate","Oats","Nuts","Unbleached flour"],"spec":{"Weight":"840 g","Pack":"12 cookies","Shelf life":"10 days"}},
    
    {"id":9,"name":"Oatmeal Raisin Cookie","category":"cookies","price":2.25,"rating":4.4,"img":"images/cookie.jpg","desc":"Wholesome oats, plump raisins and warm cinnamon.","ingredients":["Rolled oats","Raisins","Cinnamon","Butter","Brown sugar"],"spec":{"Weight":"70 g","Pack":"Single","Shelf life":"7 days"}},


    {"id":10,"name":"Classic Apple Pie","category":"pies","price":22,"rating":4.8,"img":"images/pie.jpg","desc":"Lattice-topped all-butter crust with cinnamon spiced apples.","ingredients":["Fresh apples","Cinnamon","Real butter","Unbleached flour","Cane sugar"],"spec":{"Size":"9 inch","Serves":"8","Shelf life":"3 days"}},

    {"id":11,"name":"Apple Pie Slice","category":"pies","price":4.75,"rating":4.6,"img":"images/Pies.1.jpg","desc":"Classic apple pie filled with cinnamon-spiced apples in a flaky crust.","ingredients":["Apples","Cinnamon","Butter","Flour","Sugar"],"spec":{"Weight":"160 g","Serves":"1","Shelf life":"2 days"}},

    {"id":12,"name":"Pecan Caramel Pie","category":"pies","price":26,"rating":4.7,"img":"images/Pies.2.jpg","desc":"A rich, buttery pie filled with crunchy pecans and smooth caramel, baked in a golden crust for a deliciously sweet treat.","ingredients":["Pecans","Caramel","Butter","Eggs","Unbleached flour"],"spec":{"Size":"9 inch","Serves":"8","Shelf life":"4 days"}},

      {"id":130,"name":"Cherry Pie","category":"pies","price":26,"rating":4.7,"img":"images/Pies.4.jpg","desc":"Sweet and tart cherry filling inside a crispy pastry crust.","ingredients":["Pecans","Caramel","Butter","Eggs","Unbleached flour"],"spec":{"Size":"9 inch","Serves":"8","Shelf life":"4 days"}},

      {"id":140,"name":"Strawberry Pie","category":"pies","price":26,"rating":4.7,"img":"images/Pies.5.jpg","desc":"Fresh strawberry filling with a sweet, delicate crust.","ingredients":["Pecans","Caramel","Butter","Eggs","Unbleached flour"],"spec":{"Size":"9 inch","Serves":"8","Shelf life":"4 days"}},

      
      {"id":150,"name":"Banana Cream Pie","category":"pies","price":26,"rating":4.7,"img":"images/Pies.6.jpg","desc":"Creamy banana custard layered with fresh bananas and whipped cream.","ingredients":["Pecans","Caramel","Butter","Eggs","Unbleached flour"],"spec":{"Size":"9 inch","Serves":"8","Shelf life":"4 days"}},


 {"id":13,"name":"Red Velvet Cake","category":"cakes","price":24.99,"rating":4.7,"img":"images/Cake.15.jpg","desc":"Moist red velvet sponge with creamy cheese frosting and a hint of vanilla.","ingredients":["Pecans","Caramel","Butter","Eggs","Unbleached flour"],"spec":{"Size":"9 inch","Serves":"8","Shelf life":"4 days"}},

 {"id":14,"name":"Chocolate Fudge Cake","category":"cakes","price":18.99,"rating":4.9,"img":"images/cake13.jpg","desc":"Rich chocolate cake layered with smooth fudge cream and topped with chocolate ganache.","ingredients":["Pecans","Caramel","Butter","Eggs","Unbleached flour"],"spec":{"Size":"9 inch","Serves":"8","Shelf life":"4 days"}},
  {"id":15,"name":"Strawberry Delight Cake","category":"cakes","price":22.99,"rating":3.8,"img":"images/Cake.14.jpg","desc":"Soft vanilla sponge layered with fresh strawberries and whipped cream.","ingredients":["Pecans","Caramel","Butter","Eggs","Unbleached flour"],"spec":{"Size":"9 inch","Serves":"8","Shelf life":"4 days"}}
 


  ],





















  "merchandise": [
    {"id":101,"name":"Bakerz Bite Mug","category":"Mugs","price":12,"img":"images/mug.jpg","desc":"A stylish ceramic mug featuring your bakery logo.","ingredients":["Stoneware ceramic","Dishwasher safe"],"spec":{"Capacity":"350 ml","Colour":"Cream"}},

    {"id":102,"name":"Canvas Tote Bag","category":"Bags","price":15,"img":"images/tote.jpg","desc":"A beautiful gift box for presenting delicious cookies.","ingredients":["100% cotton canvas"],"spec":{"Size":"38 x 42 cm","Colour":"Natural"}},

    {"id":103,"name":"Iced Coffee Glass","category":"Glasses","price":9,"img":"images/Coffeglass.jpg","desc":"A stylish glass filled with creamy iced coffee, rich coffee flavor, and refreshing ice. Perfect for a cool and delicious coffee experience!","ingredients":["Borosilicate glass"],"spec":{"Capacity":"450 ml"}},

    {"id":104,"name":"Wooden Serving Tray","category":"Trays","price":25,"img":"images/tray.jpg","desc":"A stylish and durable wooden serving tray, perfect for serving cakes, pastries, cookies, and coffee. Its elegant design adds a premium touch to your bakery experience.","ingredients":["Solid oak wood"],"spec":{"Diameter":"35 cm"}}
  ],
  "offers": [
    {"title":"Morning Combo","discount":"20% OFF","desc":"Any coffee + croissant before 10 AM.","valid":"Daily, 7 – 10 AM","icon":"bi-cup-hot","code":"MORNING20"},
    {"title":"Buy 6 Get 2","discount":"FREE","desc":"Buy any 6 cookies and get 2 free.","valid":"All week","icon":"bi-gift","code":""},
    {"title":"Birthday Cake Deal","discount":"15% OFF","desc":"On all celebration cakes with 48h pre-order.","valid":"Until 31 Dec","icon":"bi-cake2","code":"CAKE15"},
    {"title":"Weekend Pie Feast","discount":"$5 OFF","desc":"On any whole pie every Saturday & Sunday.","valid":"Weekends","icon":"bi-star","code":"PIE5"}
  ],
  "reviews": [
    {"name":"Ayesha K.","rating":5,"msg":"Best croissants in town. Flaky and buttery!"},
    {"name":"Daniel R.","rating":4,"msg":"Loved the chocolate berry cake for my daughter's birthday."},
    {"name":"Sara M.","rating":5,"msg":"Cozy café, friendly staff, amazing cookies."}
  ]
};
