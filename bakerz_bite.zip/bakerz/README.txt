Bakerz Bite - eProject

Open index.html in Chrome/Edge/Firefox (internet needed for Bootstrap, jQuery, fonts, AOS CDN).
Tech: HTML5, CSS3, Bootstrap 5, JavaScript, jQuery, AOS animations.
Data store: data/products.json (mirrored in data/products.js so it works from file://).
Features: preloader, logo+banner carousel, Cakes/Pastries/Cookies/Pies with filters (category, search, price, sort), product popup with ingredients/specs, Merchandise, Offers, Gallery lightbox, Feedback & rating (saved in localStorage), FAQ, About, Contact, Site map, visitor counter, scrolling ticker with date/time/geolocation, scroll-to-top.
Assumptions: address/phone/email are sample data.
