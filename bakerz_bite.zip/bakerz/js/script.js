/* ==========================================================
   Bakerz Bite — jQuery + GSAP
   ========================================================== */
document.documentElement.classList.add('js-anim');

$(function () {
  var data = window.BAKERZ_DATA;
  var hasGsap = !!window.gsap;
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var allItems = data.products.concat(data.merchandise);

  /* ---------- Small helpers ---------- */
  function esc(s) { return $('<i>').text(String(s)).html(); }
  function money(p) { return '$' + (+p).toFixed(2); }
  function stars(r) {
    var s = '';
    for (var i = 1; i <= 5; i++) s += '<i class="bi ' + (r >= i ? 'bi-star-fill' : r >= i - .5 ? 'bi-star-half' : 'bi-star') + '"></i>';
    return s;
  }
  function findItem(id) { return allItems.find(function (x) { return x.id === id; }); }
  function splitChars($el) {
    $el.each(function () {
      var t = $(this).text();
      $(this).html(t.split('').map(function (c) {
        return c === ' ' ? '<span class="ch">&nbsp;</span>' : '<span class="ch">' + esc(c) + '</span>';
      }).join(''));
    });
  }
  function store(key, val) {
    if (val === undefined) { try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; } }
    localStorage.setItem(key, JSON.stringify(val));
  }

  /* ==========================================================
     PRELOADER — "The First Bite"
     outline draws → cookie bakes → chips pop → a bite is taken
     → crumbs fly → oven doors open
     ========================================================== */
  var pageLoaded = false, introDone = false;
  $(window).on('load', function () { pageLoaded = true; });
  setTimeout(function () { pageLoaded = true; }, 3500);

  // split title: "Bakerz " cream, "Bite" gold
  var $plTitle = $('#plTitle');
  $plTitle.html('Bakerz Bite'.split('').map(function (c, i) {
    return '<span class="ch' + (i > 6 ? ' gold' : '') + '">' + (c === ' ' ? '&nbsp;' : c) + '</span>';
  }).join(''));

  function finishPreloader() {
    if (introDone) return; introDone = true;
    $('body').removeClass('is-loading');
    if (!hasGsap) { $('#preloader').addClass('hide'); heroIntro(); return; }
    var tl = gsap.timeline({ onComplete: function () { $('#preloader').remove(); } });
    tl.to('.pl-center', { scale: .85, opacity: 0, duration: .5, ease: 'power3.in' })
      .to('.pl-glow', { opacity: 0, duration: .3 }, '<')
      .to('.pl-top', { yPercent: -100, duration: 1, ease: 'expo.inOut' }, '-=.1')
      .to('.pl-bottom', { yPercent: 100, duration: 1, ease: 'expo.inOut' }, '<')
      .add(heroIntro, '-=.55');
  }

  function crumbBurst() {
    var $c = $('#plCrumbs');
    for (var i = 0; i < 18; i++) {
      var $b = $('<i>').appendTo($c);
      var size = 3 + Math.random() * 7;
      $b.css({ width: size, height: size, background: Math.random() > .3 ? '#e0a94f' : '#3a1f12' });
      gsap.fromTo($b[0], { x: 0, y: 0, opacity: 1, rotate: 0 }, {
        x: 30 + Math.random() * 110, y: -60 + Math.random() * 160, rotate: Math.random() * 360,
        opacity: 0, duration: .9 + Math.random() * .6, ease: 'power2.out'
      });
    }
  }

  if (hasGsap && !reduceMotion) {
    var pct = { v: 0 };
    var subs = ['Preheating the oven', 'Mixing the dough', 'Adding chocolate chips', 'Taking the first bite'];
    var pl = gsap.timeline();
    pl.from('#plTitle .ch', { yPercent: 120, opacity: 0, stagger: .05, duration: .7, ease: 'back.out(1.7)' }, 0)
      .to('.pl-outline', { strokeDashoffset: 0, duration: 1.1, ease: 'power2.inOut' }, 0)
      .to(pct, {
        v: 100, duration: 2.6, ease: 'power1.inOut',
        onUpdate: function () {
          var v = Math.round(pct.v);
          $('#plPct').text(v); $('#plBar').css('width', v + '%');
          $('#plSub').text(subs[Math.min(3, Math.floor(v / 26))]);
        }
      }, 0)
      .fromTo('.pl-fill', { opacity: 0, scale: .6, transformOrigin: '50% 50%' }, { opacity: 1, scale: 1, duration: .7, ease: 'back.out(1.6)' }, .9)
      .fromTo('.pl-chips ellipse', { opacity: 0, scale: 0, transformOrigin: '50% 50%' }, { opacity: 1, scale: 1, duration: .4, stagger: .07, ease: 'back.out(3)' }, 1.3)
      .addLabel('bite', 2.1)
      .to('.pl-cookie', { rotate: -8, scale: 1.06, duration: .12, yoyo: true, repeat: 3, ease: 'power1.inOut' }, 'bite')
      .add(function () { crumbBurst(); }, 'bite+=.05');
    $('.bite-c').each(function (i) {
      pl.to(this, { attr: { r: +$(this).data('r') }, duration: .28, ease: 'back.out(2)' }, 'bite+=' + (i * .09));
    });
    pl.add(function () { $('#plSub').text('Mmm… perfect!'); }, 'bite+=.4');
    pl.add(function waitLoad() {
      (function check() { pageLoaded ? finishPreloader() : setTimeout(check, 100); })();
    }, '+=.35');
  } else {
    $(window).on('load', function () { setTimeout(finishPreloader, 300); });
    setTimeout(finishPreloader, 2500);
  }
  setTimeout(finishPreloader, 7000); // ultimate fallback

  /* ---------- Hero intro ---------- */
  splitChars($('.hero-title .split'));
  function heroIntro() {
    AOS.init({ duration: 900, once: true, offset: 80, easing: 'ease-out-cubic' });
    if (!hasGsap || reduceMotion) { $('.hero-anim').css({ opacity: 1, transform: 'none' }); return; }
    var tl = gsap.timeline();
    tl.from('.hero .carousel-inner', { scale: 1.25, duration: 2.2, ease: 'expo.out' }, 0)
      .to('.hero-anim', { opacity: 1, y: 0, duration: .9, stagger: .12, ease: 'power3.out' }, .2)
      .from('.hero-title .ch', { yPercent: 115, rotate: 12, opacity: 0, duration: .9, stagger: .025, ease: 'back.out(1.6)' }, .35)
      .from('.spin-badge', { scale: 0, rotate: -180, duration: 1.2, ease: 'back.out(1.5)' }, .8)
      .from('.navbar', { y: -90, opacity: 0, duration: .9, ease: 'power3.out', clearProps: 'transform,opacity' }, .2);
  }

  /* ---------- Hero golden dust particles ---------- */
  (function dust() {
    var cv = document.getElementById('heroDust'); if (!cv || reduceMotion) return;
    var ctx = cv.getContext('2d'), w, h, parts = [];
    function size() { w = cv.width = cv.offsetWidth; h = cv.height = cv.offsetHeight; }
    size(); $(window).on('resize', size);
    for (var i = 0; i < 70; i++) parts.push({ x: Math.random() * w, y: Math.random() * h, r: Math.random() * 2.2 + .4, s: Math.random() * .5 + .15, d: Math.random() * Math.PI * 2, a: Math.random() * .6 + .2 });
    var heroVisible = true;
    $(window).on('scroll', function () { heroVisible = $(window).scrollTop() < h; });
    (function loop() {
      if (heroVisible) {
        ctx.clearRect(0, 0, w, h);
        parts.forEach(function (p) {
          p.y -= p.s; p.d += .01; p.x += Math.sin(p.d) * .35;
          if (p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(243,205,133,' + p.a + ')';
          ctx.shadowBlur = 8; ctx.shadowColor = 'rgba(224,169,79,.8)'; ctx.fill();
        });
      }
      requestAnimationFrame(loop);
    })();
  })();

  // hero mouse parallax
  $('.hero').on('mousemove', function (e) {
    if (!hasGsap) return;
    var x = (e.clientX / window.innerWidth - .5), y = (e.clientY / window.innerHeight - .5);
    gsap.to('#heroContent', { x: x * -24, y: y * -16, duration: 1.2, ease: 'power3.out' });
    gsap.to('.spin-badge', { x: x * 40, y: y * 30, duration: 1.2, ease: 'power3.out' });
  });

  $('#year').text(new Date().getFullYear());

  /* ---------- Open / closed status ---------- */
  function openStatus() {
    var now = new Date(), d = now.getDay(), h = now.getHours() + now.getMinutes() / 60;
    var weekend = d === 0 || d === 6, open = weekend ? 8 : 7, close = weekend ? 23 : 22;
    var isOpen = h >= open && h < close;
    var fmt = function (x) { return (x > 12 ? x - 12 : x) + (x >= 12 ? ' PM' : ' AM'); };
    $('.open-status').text(isOpen ? 'Open now · closes ' + fmt(close) : 'Closed · opens ' + fmt(open));
    $('.live-dot').toggleClass('closed', !isOpen);
  }
  openStatus(); setInterval(openStatus, 60000);

  /* ---------- Visitor counter (localStorage) ---------- */
  var count = parseInt(localStorage.getItem('bb_visits') || '1250', 10) + 1;
  localStorage.setItem('bb_visits', count);
  $({ n: 0 }).animate({ n: count }, { duration: 2200, step: function (v) { $('#visitorCount').text(Math.floor(v).toLocaleString()); }, complete: function () { $('#visitorCount').text(count.toLocaleString()); } });

  /* ---------- Navbar, scroll progress, scroll top ---------- */
  var lastTop = 0;
  var ringLen = 144.5;
  $(window).on('scroll', function () {
    var top = $(this).scrollTop();
    var max = $(document).height() - $(window).height();
    var prog = max > 0 ? top / max : 0;
    $('#mainNav').toggleClass('scrolled', top > 60);
    $('#mainNav').toggleClass('nav-hidden', top > lastTop && top > 600 && !$('#navMenu').hasClass('show'));
    lastTop = top;
    $('#scrollProgress').css('transform', 'scaleX(' + prog + ')');
    $('#topRing').css('stroke-dashoffset', ringLen * (1 - prog));
    $('#scrollTop').toggleClass('show', top > 400);
    $('section, header').each(function () {
      var id = $(this).attr('id');
      if (top >= $(this).offset().top - 120) {
        $('.nav-link').removeClass('active');
        $('.nav-link[href="#' + id + '"]').addClass('active');
      }
    });
    // about image parallax
    var $pi = $('.parallax-img');
    if ($pi.length) {
      var off = ($pi.offset().top - top - window.innerHeight / 2) * -0.05;
      $pi.css('transform', 'translateY(' + off + 'px) scale(1.06)');
    }
  });

  // smooth scroll
  $(document).on('click', 'a[href^="#"]', function (e) {
    var target = $(this).attr('href');
    if ($(this).is('[data-bs-toggle]') && !$(this).is('[data-bs-dismiss]')) return;
    if (target.length > 1 && $(target).length) {
      e.preventDefault();
      var go = function () { $('html, body').stop().animate({ scrollTop: $(target).offset().top - 70 }, 900); };
      $(this).closest('.offcanvas').length ? setTimeout(go, 400) : go();
      if ($('#navMenu').hasClass('show')) bootstrap.Collapse.getOrCreateInstance('#navMenu').hide();
    }
  });
  $('#scrollTop').on('click', function (e) { e.preventDefault(); $('html, body').animate({ scrollTop: 0 }, 900); });

  /* ---------- Custom cursor ---------- */
  if (window.matchMedia('(pointer:fine)').matches && hasGsap && !reduceMotion) {
    $('body').addClass('cursor-on');
    var dotX = gsap.quickTo('#cursorDot', 'x', { duration: .1 }), dotY = gsap.quickTo('#cursorDot', 'y', { duration: .1 });
    var rX = gsap.quickTo('#cursorRing', 'x', { duration: .45, ease: 'power3' }), rY = gsap.quickTo('#cursorRing', 'y', { duration: .45, ease: 'power3' });
    $(window).one('mousemove', function () { $('body').addClass('cursor-moved'); });
    $(document).on('mouseleave', function () { $('body').removeClass('cursor-moved'); }).on('mouseenter', function () { $('body').addClass('cursor-moved'); });
    $(window).on('mousemove', function (e) { dotX(e.clientX); dotY(e.clientY); rX(e.clientX); rY(e.clientY); });
    $(document).on('mouseenter', 'a, button, .product-card, .g-item, .filter-btn, .star-input i, .code-chip', function () { $('#cursorRing').addClass('hover'); })
      .on('mouseleave', 'a, button, .product-card, .g-item, .filter-btn, .star-input i, .code-chip', function () { $('#cursorRing').removeClass('hover'); });
  }

  /* ---------- Magnetic buttons + ripple ---------- */
  if (hasGsap && window.matchMedia('(pointer:fine)').matches) {
    $(document).on('mousemove', '.magnetic', function (e) {
      var r = this.getBoundingClientRect();
      gsap.to(this, { x: (e.clientX - r.left - r.width / 2) * .3, y: (e.clientY - r.top - r.height / 2) * .4, duration: .4, ease: 'power3.out' });
    }).on('mouseleave', '.magnetic', function () { gsap.to(this, { x: 0, y: 0, duration: .7, ease: 'elastic.out(1,.4)' }); });
  }
  $(document).on('click', '.btn-bake, .add-btn, .btn-outline-bake', function (e) {
    var r = this.getBoundingClientRect(), s = Math.max(r.width, r.height);
    var $rp = $('<span class="ripple">').css({ width: s, height: s, left: e.clientX - r.left - s / 2, top: e.clientY - r.top - s / 2 });
    $(this).append($rp); setTimeout(function () { $rp.remove(); }, 700);
  });

  /* ---------- Stat counters ---------- */
  var counted = false;
  $(window).on('scroll', function () {
    if (!counted && $(window).scrollTop() + $(window).height() > $('#about .stat').offset().top) {
      counted = true;
      $('.counter').each(function () {
        var $t = $(this), to = +$t.data('target');
        $({ n: 0 }).animate({ n: to }, { duration: 2200, easing: 'swing', step: function (v) { $t.text(Math.floor(v).toLocaleString() + '+'); }, complete: function () { $t.text(to.toLocaleString() + '+'); } });
      });
    }
  });

  /* ==========================================================
     WISHLIST + CART (saved in localStorage)
     ========================================================== */
  var wish = store('bb_wish') || [];
  var cart = store('bb_cart') || [];          // [{id, qty}]
  var promo = store('bb_promo') || null;     // {code, type, value}
  var PROMOS = {
    BITE10: { type: 'pct', value: 10, label: '10% off your order' },
    MORNING20: { type: 'pct', value: 20, label: '20% Morning Combo discount' },
    CAKE15: { type: 'pct', value: 15, label: '15% off celebration cakes' },
    PIE5: { type: 'flat', value: 5, label: '$5 off your pie feast' }
  };

  function isWished(id) { return wish.indexOf(id) > -1; }
  function toggleWish(id) {
    if (isWished(id)) { wish = wish.filter(function (x) { return x !== id; }); toast('Removed from saved', 'bi-heart'); }
    else { wish.push(id); toast('Saved to your favourites', 'bi-heart-fill'); }
    store('bb_wish', wish);
    $('.wish-btn[data-id="' + id + '"]').toggleClass('on', isWished(id)).find('i').attr('class', 'bi ' + (isWished(id) ? 'bi-heart-fill' : 'bi-heart'));
    if (state.cat === 'saved') renderProducts();
  }

  function cartTotals() {
    var sub = cart.reduce(function (s, c) { var p = findItem(c.id); return s + (p ? p.price * c.qty : 0); }, 0);
    var disc = 0;
    if (promo && sub > 0) disc = promo.type === 'pct' ? sub * promo.value / 100 : Math.min(promo.value, sub);
    return { sub: sub, disc: disc, total: sub - disc, count: cart.reduce(function (s, c) { return s + c.qty; }, 0) };
  }
  function renderCart() {
    var t = cartTotals();
    $('#cartCount').text(t.count);
    $('#cartEmpty').toggle(cart.length === 0);
    $('#cartFooter').toggle(cart.length > 0);
    $('#cartItems').html(cart.map(function (c) {
      var p = findItem(c.id); if (!p) return '';
      return '<div class="cart-item" data-id="' + p.id + '"><img src="' + p.img + '" alt="' + esc(p.name) + '">' +
        '<div class="ci-info"><h6>' + esc(p.name) + '</h6><div class="qty"><button type="button" class="ci-minus">−</button><span>' + c.qty + '</span><button type="button" class="ci-plus">+</button></div></div>' +
        '<div class="ci-right"><b>' + money(p.price * c.qty) + '</b><button class="ci-remove" aria-label="Remove"><i class="bi bi-trash3"></i></button></div></div>';
    }).join(''));
    $('#cSub').text(money(t.sub));
    $('#discRow').toggleClass('show', t.disc > 0); $('#cDisc').text('-' + money(t.disc));
    $('#cTotal').text(money(t.total)); $('#oTotal').text(money(t.total));
    if (promo) $('#promoMsg').attr('class', 'promo-msg ok').text('✓ ' + promo.code + ' — ' + promo.label);
    store('bb_cart', cart);
  }
  function addToCart(id, qty, srcImg) {
    qty = qty || 1;
    var line = cart.find(function (c) { return c.id === id; });
    if (line) line.qty += qty; else cart.push({ id: id, qty: qty });
    renderCart();
    flyToCart(srcImg);
    toast(findItem(id).name + ' added to basket', 'bi-bag-check-fill');
  }
  function flyToCart(img) {
    $('#mainNav').removeClass('nav-hidden');
    var $btn = $('.cart-btn');
    var bump = function () { $btn.removeClass('bump'); void $btn[0].offsetWidth; $btn.addClass('bump'); };
    if (!img || !hasGsap || reduceMotion) return bump();
    var r = img.getBoundingClientRect(), t = $btn[0].getBoundingClientRect();
    var $f = $('<img class="fly-img">').attr('src', img.src).css({ left: r.left, top: r.top, width: r.width, height: r.height, borderRadius: '16px' }).appendTo('body');
    gsap.timeline({ onComplete: function () { $f.remove(); bump(); } })
      .to($f[0], { width: 70, height: 70, left: r.left + r.width / 2 - 35, top: r.top + r.height / 2 - 35, borderRadius: '50%', duration: .35, ease: 'power2.out' })
      .to($f[0], { left: t.left + t.width / 2 - 10, top: t.top + t.height / 2 - 10, width: 20, height: 20, opacity: .6, duration: .75, ease: 'power3.in' });
  }
  $(document).on('click', '.ci-plus, .ci-minus', function () {
    var id = +$(this).closest('.cart-item').data('id'), line = cart.find(function (c) { return c.id === id; });
    line.qty += $(this).hasClass('ci-plus') ? 1 : -1;
    if (line.qty < 1) cart = cart.filter(function (c) { return c.id !== id; });
    renderCart();
  });
  $(document).on('click', '.ci-remove', function () {
    var $it = $(this).closest('.cart-item'), id = +$it.data('id');
    $it.addClass('removing');
    setTimeout(function () { cart = cart.filter(function (c) { return c.id !== id; }); renderCart(); }, 380);
  });
  $('#promoForm').on('submit', function (e) {
    e.preventDefault();
    var code = $('#promoInput').val().trim().toUpperCase();
    if (PROMOS[code]) {
      promo = $.extend({ code: code }, PROMOS[code]); store('bb_promo', promo); renderCart();
      $('#promoInput').val(''); confetti(40); toast('Promo applied: ' + code, 'bi-ticket-perforated-fill');
    } else {
      $('#promoMsg').attr('class', 'promo-msg bad').text('That code isn’t valid. Try BITE10');
      if (hasGsap) gsap.fromTo('#promoInput', { x: -8 }, { x: 0, duration: .5, ease: 'elastic.out(1,.3)' });
    }
  });
  renderCart();

  /* ---------- Checkout ---------- */
  var checkoutModal = new bootstrap.Modal('#checkoutModal');
  $('#checkoutBtn').on('click', function () {
    bootstrap.Offcanvas.getOrCreateInstance('#cartPanel').hide();
    $('#checkoutForm').show(); $('#orderSuccess').hide(); $('#oError').text('');
    setTimeout(function () { checkoutModal.show(); }, 300);
  });
  $('input[name="otype"]').on('change', function () { $('#addrWrap').stop(true, true)[this.value === 'Delivery' ? 'slideDown' : 'slideUp'](250); });
  $('#orderForm').on('submit', function (e) {
    e.preventDefault();
    var name = $('#oName').val().trim(), phone = $('#oPhone').val().trim(), type = $('input[name="otype"]:checked').val(), addr = $('#oAddr').val().trim();
    if (name.length < 2) return $('#oError').text('Please enter your name.');
    if (!/^[+\d][\d\s-]{6,}$/.test(phone)) return $('#oError').text('Please enter a valid phone number.');
    if (type === 'Delivery' && addr.length < 5) return $('#oError').text('Please enter your delivery address.');
    var no = 'BB-' + Math.floor(1000 + Math.random() * 9000);
    var t = cartTotals();
    var orders = store('bb_orders') || [];
    orders.push({ no: no, name: name, phone: phone, type: type, addr: addr, items: cart, total: t.total, at: new Date().toISOString() });
    store('bb_orders', orders);
    $('#orderNo').text(no);
    $('#orderMsg').text(type === 'Pickup' ? 'Your treats will be ready for pickup in about 30 minutes.' : 'Your treats are on their way — about 45 minutes.');
    $('#checkoutForm').hide(); $('#orderSuccess').fadeIn(300);
    cart = []; promo = null; store('bb_promo', null); $('#promoMsg').text(''); renderCart();
    this.reset(); $('#addrWrap').hide();
    confetti(120);
  });

  /* ==========================================================
     PRODUCTS + FILTERS
     ========================================================== */
  function card(p, isMerch) {
    var badge = p.rating >= 4.9 ? 'Bestseller' : (p.rating >= 4.8 ? 'Popular' : '');
    return '<div class="col-sm-6 col-lg-' + (isMerch ? '3' : '4') + ' product-col">' +
      '<article class="product-card" data-id="' + p.id + '">' +
      '<div class="img-wrap"><img src="' + p.img + '" alt="' + esc(p.name) + '" loading="lazy">' +
      (badge && !isMerch ? '<span class="badge-tag">' + badge + '</span>' : '') +
      '<button class="wish-btn' + (isWished(p.id) ? ' on' : '') + '" data-id="' + p.id + '" aria-label="Save"><i class="bi ' + (isWished(p.id) ? 'bi-heart-fill' : 'bi-heart') + '"></i></button>' +
      '<div class="quick"><i class="bi bi-eye me-1"></i> Quick view</div></div>' +
      '<div class="body"><span class="cat-pill">' + esc(p.category) + '</span><h5>' + esc(p.name) + '</h5>' +
      (p.rating ? '<div class="stars">' + stars(p.rating) + '<small>' + p.rating + '</small></div>' : '') +
      '<div class="card-foot"><span class="price">' + money(p.price) + '</span>' +
      '<button class="add-btn" data-id="' + p.id + '"><i class="bi bi-bag-plus"></i> Add</button></div></div>' +
      '<span class="shine"></span></article></div>';
  }
  function animateIn($cols) {
    if (!hasGsap || reduceMotion) return;
    gsap.fromTo($cols.toArray(), { opacity: 0, y: 50, scale: .92, rotateX: -12 }, { opacity: 1, y: 0, scale: 1, rotateX: 0, duration: .8, stagger: .06, ease: 'power3.out', clearProps: 'transform' });
  }

  var state = { cat: 'all', q: '', price: 'all', sort: 'default' };
  function renderProducts() {
    var list = data.products.filter(function (p) {
      var okCat = state.cat === 'all' || (state.cat === 'saved' ? isWished(p.id) : p.category === state.cat);
      var okQ = (p.name + ' ' + p.desc).toLowerCase().indexOf(state.q) > -1;
      var okP = true;
      if (state.price !== 'all') { var r = state.price.split('-'); okP = p.price >= +r[0] && p.price < +r[1]; }
      return okCat && okQ && okP;
    });
    if (state.sort === 'low') list.sort(function (a, b) { return a.price - b.price; });
    if (state.sort === 'high') list.sort(function (a, b) { return b.price - a.price; });
    if (state.sort === 'rating') list.sort(function (a, b) { return b.rating - a.rating; });
    var $g = $('#productGrid');
    var draw = function () {
      $g.html(list.map(function (p) { return card(p); }).join(''));
      $('#noResults').toggle(list.length === 0);
      $('#noResults p').text(state.cat === 'saved' ? 'No saved treats yet — tap the heart on anything you love.' : 'No treats match your filters.');
      $('#resultCount').html('Showing <b>' + list.length + '</b> of ' + data.products.length + ' treats');
      animateIn($g.children());
    };
    if (hasGsap && $g.children().length && !reduceMotion) {
      gsap.to($g.children().toArray(), { opacity: 0, y: 20, scale: .96, duration: .22, stagger: .015, onComplete: draw });
    } else draw();
  }
  renderProducts();

  function moveIndicator() {
    var $a = $('.filter-btn.active'); if (!$a.length) return;
    $('#filterIndicator').css({ width: $a.outerWidth(), height: $a.outerHeight(), left: $a.position().left, top: $a.position().top });
  }
  setTimeout(moveIndicator, 50); $(window).on('resize load', moveIndicator);
  if (document.fonts) document.fonts.ready.then(moveIndicator);

  $('.filter-btn').on('click', function () {
    $('.filter-btn').removeClass('active'); $(this).addClass('active'); moveIndicator();
    state.cat = $(this).data('filter'); renderProducts();
  });
  var searchT;
  $('#searchInput').on('input', function () { var v = $(this).val().toLowerCase().trim(); clearTimeout(searchT); searchT = setTimeout(function () { state.q = v; renderProducts(); }, 220); });
  $('#priceFilter').on('change', function () { state.price = $(this).val(); renderProducts(); });
  $('#sortFilter').on('change', function () { state.sort = $(this).val(); renderProducts(); });

  /* ---------- Merchandise ---------- */
  $('#merchGrid').html(data.merchandise.map(function (m) { return card(m, true); }).join(''));
  $('#merchGrid .product-col').each(function (i) { $(this).attr({ 'data-aos': 'fade-up', 'data-aos-delay': i * 100 }); });

  /* ---------- 3D tilt + shine on cards ---------- */
  if (window.matchMedia('(pointer:fine)').matches && !reduceMotion) {
    $(document).on('mousemove', '.product-card', function (e) {
      var r = this.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      this.style.transform = 'rotateY(' + ((x - .5) * 10) + 'deg) rotateX(' + ((.5 - y) * 10) + 'deg) translateY(-8px)';
      this.style.setProperty('--mx', (x * 100) + '%'); this.style.setProperty('--my', (y * 100) + '%');
    }).on('mouseleave', '.product-card', function () { this.style.transform = ''; });
  }

  /* ---------- Offers ---------- */
  $('#offerGrid').html(data.offers.map(function (o, i) {
    var chip = o.code ? '<span class="code-chip" data-code="' + o.code + '"><i class="bi bi-ticket-perforated"></i> ' + o.code + '</span>'
      : '<span class="code-chip muted"><i class="bi bi-shop"></i> Applied at counter</span>';
    return '<div class="col-sm-6 col-lg-3" data-aos="flip-up" data-aos-delay="' + (i * 120) + '"><div class="offer-card">' +
      '<i class="bi ' + o.icon + '"></i><div class="disc">' + o.discount + '</div><h4>' + o.title + '</h4><p>' + o.desc + '</p><small><i class="bi bi-clock me-1"></i>' + o.valid + '</small><br>' + chip + '</div></div>';
  }).join(''));
  $(document).on('click', '.code-chip[data-code]', function () {
    var code = $(this).data('code');
    if (navigator.clipboard) navigator.clipboard.writeText(code).catch(function () { });
    $('#promoInput').val(code);
    toast('Code ' + code + ' copied — paste it in your basket', 'bi-clipboard-check-fill');
  });

  // countdown to midnight
  function countdown() {
    var now = new Date(), end = new Date(now); end.setHours(24, 0, 0, 0);
    var s = Math.floor((end - now) / 1000);
    var vals = { cdH: Math.floor(s / 3600), cdM: Math.floor(s % 3600 / 60), cdS: s % 60 };
    $.each(vals, function (k, v) {
      var $el = $('#' + k), txt = String(v).padStart(2, '0');
      if ($el.text() !== txt) { $el.text(txt).removeClass('tick'); void $el[0].offsetWidth; $el.addClass('tick'); }
    });
  }
  countdown(); setInterval(countdown, 1000);

  /* ---------- Product modal ---------- */
  var modal = new bootstrap.Modal('#productModal');
  var current = null, mQty = 1;
  $(document).on('click', '.product-card', function (e) {
    var id = +$(this).data('id');
    if ($(e.target).closest('.wish-btn').length) { toggleWish(id); return; }
    if ($(e.target).closest('.add-btn').length) {
      addToCart(id, 1, $(this).find('img')[0]);
      var $b = $(e.target).closest('.add-btn').addClass('added').html('<i class="bi bi-check2"></i> Added');
      setTimeout(function () { $b.removeClass('added').html('<i class="bi bi-bag-plus"></i> Add'); }, 1400);
      return;
    }
    var p = findItem(id); current = p; mQty = 1; $('#qVal').text(1);
    $('#mImg').attr({ src: p.img, alt: p.name });
    $('#mCat').text(p.category); $('#mName').text(p.name);
    $('#mRating').html(p.rating ? stars(p.rating) + ' <small>' + p.rating + '</small>' : '');
    $('#mPrice').text(money(p.price)); $('#mDesc').text(p.desc);
    $('#mIng').html(p.ingredients.map(function (i) { return '<li>' + esc(i) + '</li>'; }).join(''));
    $('#mSpec').html(Object.keys(p.spec).map(function (k) { return '<li><b>' + esc(k) + ':</b> ' + esc(p.spec[k]) + '</li>'; }).join(''));
    $('#mWish').attr('data-id', p.id).toggleClass('on', isWished(p.id)).find('i').attr('class', 'bi ' + (isWished(p.id) ? 'bi-heart-fill' : 'bi-heart'));
    modal.show();
  });
  $('#qPlus').on('click', function () { $('#qVal').text(++mQty); });
  $('#qMinus').on('click', function () { if (mQty > 1) $('#qVal').text(--mQty); });
  $('#mAdd').on('click', function () { if (!current) return; addToCart(current.id, mQty, $('#mImg')[0]); modal.hide(); });
  $('#mWish').on('click', function () { if (current) toggleWish(current.id); });

  /* ---------- Gallery lightbox (prev / next / keyboard) ---------- */
  var $gItems = $('.g-item'), gIndex = 0;
  function showLb(i) {
    gIndex = (i + $gItems.length) % $gItems.length;
    var $it = $gItems.eq(gIndex);
    $('#lightbox img').attr('src', $it.attr('href')).css('animation', 'none');
    void $('#lightbox img')[0].offsetWidth; $('#lightbox img').css('animation', '');
    $('#lbCap').text($it.find('img').attr('alt') + '  ·  ' + (gIndex + 1) + ' / ' + $gItems.length);
  }
  $gItems.on('click', function (e) { e.preventDefault(); showLb($gItems.index(this)); $('#lightbox').css('display', 'flex').hide().fadeIn(300); });
  $('.lb-prev').on('click', function (e) { e.stopPropagation(); showLb(gIndex - 1); });
  $('.lb-next').on('click', function (e) { e.stopPropagation(); showLb(gIndex + 1); });
  $('#lightbox').on('click', function (e) { if (e.target.tagName !== 'IMG') $(this).fadeOut(300); });
  $(document).on('keydown', function (e) {
    if (!$('#lightbox').is(':visible')) return;
    if (e.key === 'Escape') $('#lightbox').fadeOut(300);
    if (e.key === 'ArrowRight') showLb(gIndex + 1);
    if (e.key === 'ArrowLeft') showLb(gIndex - 1);
  });

  /* ---------- Feedback & rating ---------- */
  var reviews = store('bb_reviews') || data.reviews.slice();
  var chosen = 0, words = ['', 'Not great', 'Okay', 'Good', 'Very good', 'Delicious!'];
  function renderReviews(isNew) {
    var avg = reviews.reduce(function (s, r) { return s + r.rating; }, 0) / (reviews.length || 1);
    $('#avgRating').text(avg.toFixed(1)); $('#reviewCount').text(reviews.length);
    var bars = '';
    for (var s = 5; s >= 1; s--) {
      var n = reviews.filter(function (r) { return r.rating === s; }).length;
      bars += '<div class="rbar"><span>' + s + ' <i class="bi bi-star-fill"></i></span><div class="track"><div class="fill" data-w="' + (reviews.length ? n / reviews.length * 100 : 0) + '"></div></div><span>' + n + '</span></div>';
    }
    $('#ratingBars').html(bars);
    setTimeout(function () { $('#ratingBars .fill').each(function () { $(this).css('width', $(this).data('w') + '%'); }); }, 100);
    $('#reviewList').html(reviews.slice().reverse().map(function (r, i) {
      return '<div class="review' + (isNew && i === 0 ? ' new' : '') + '"><div class="d-flex align-items-center mb-2"><span class="avatar">' + esc(r.name.charAt(0).toUpperCase()) + '</span>' +
        '<div><b>' + esc(r.name) + '</b><div class="stars">' + stars(r.rating) + '</div></div></div><p class="mb-0">' + esc(r.msg) + '</p></div>';
    }).join(''));
  }
  renderReviews();
  function paintStars(v) { $('#starInput i').each(function () { $(this).toggleClass('on', +$(this).data('v') <= v); }); $('#rateWord').text(words[v] || ''); }
  $('#starInput i').on('mouseenter', function () { paintStars(+$(this).data('v')); })
    .on('click', function () {
      chosen = +$(this).data('v'); paintStars(chosen);
      $('#starInput i').slice(0, chosen).each(function (i) { var $s = $(this); setTimeout(function () { $s.removeClass('pop'); void $s[0].offsetWidth; $s.addClass('pop'); }, i * 60); });
    });
  $('#starInput').on('mouseleave', function () { paintStars(chosen); });
  $('#fbMsg').on('input', function () { $('#fbChars').text($(this).val().length); });

  $('#feedbackForm').on('submit', function (e) {
    e.preventDefault();
    var name = $('#fbName').val().trim(), email = $('#fbEmail').val().trim(), msg = $('#fbMsg').val().trim();
    var err = function (m) { $('#fbError').text(m); if (hasGsap) gsap.fromTo('#feedbackForm', { x: -10 }, { x: 0, duration: .6, ease: 'elastic.out(1,.3)' }); };
    if (!name || !msg) return err('Please enter your name and message.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return err('Please enter a valid email.');
    if (!chosen) return err('Please select a rating.');
    $('#fbError').text('');
    reviews.push({ name: name, rating: chosen, msg: msg });
    store('bb_reviews', reviews);
    renderReviews(true); this.reset(); chosen = 0; paintStars(0); $('#fbChars').text(0);
    toast('Thank you for your feedback!', 'bi-heart-fill'); confetti(80);
  });

  $('#contactForm').on('submit', function (e) {
    e.preventDefault();
    var ok = $('#cName').val().trim() && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test($('#cEmail').val().trim()) && $('#cMsg').val().trim();
    if (!ok) { toast('Please fill in your name, a valid email and a message.', 'bi-exclamation-circle-fill'); return; }
    this.reset(); toast('Message sent! We\'ll get back to you soon.', 'bi-send-check-fill');
  });
  $('#newsForm').on('submit', function (e) {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test($('#newsEmail').val().trim())) { toast('Please enter a valid email.', 'bi-exclamation-circle-fill'); return; }
    this.reset(); toast('Welcome! Your code BITE10 gives 10% off.', 'bi-envelope-heart-fill'); confetti(60);
  });

  /* ---------- Toast ---------- */
  var toastT;
  function toast(msg, icon) {
    var $t = $('#toast');
    $t.find('i').attr('class', 'bi ' + (icon || 'bi-check-circle-fill'));
    $t.find('span').text(msg);
    $t.removeClass('show'); void $t[0].offsetWidth; $t.addClass('show');
    clearTimeout(toastT); toastT = setTimeout(function () { $t.removeClass('show'); }, 2800);
  }

  /* ---------- Confetti ---------- */
  function confetti(n) {
    if (!hasGsap || reduceMotion) return;
    var colors = ['#f3cd85', '#e0a94f', '#c9435a', '#f6ead7', '#b97a2e', '#e0697d'];
    var $c = $('#confetti');
    for (var i = 0; i < n; i++) {
      var $p = $('<i>').css({ left: Math.random() * 100 + '%', background: colors[i % colors.length], borderRadius: Math.random() > .5 ? '50%' : '2px' }).appendTo($c);
      gsap.to($p[0], {
        y: window.innerHeight + 60, x: (Math.random() - .5) * 300, rotation: Math.random() * 720,
        duration: 1.8 + Math.random() * 1.6, delay: Math.random() * .4, ease: 'power1.in',
        onComplete: function () { $(this.targets()[0]).remove(); }
      });
    }
  }

  /* ---------- Ticker: date, time, location ---------- */
  var locationText = 'Detecting location...';
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function (pos) {
      var lat = pos.coords.latitude.toFixed(4), lon = pos.coords.longitude.toFixed(4);
      locationText = 'Lat ' + lat + ', Lon ' + lon;
      $.getJSON('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lat + '&lon=' + lon, function (r) {
        var a = r.address || {};
        locationText = [a.city || a.town || a.village, a.country].filter(Boolean).join(', ') || locationText;
      });
    }, function () { locationText = 'Location unavailable'; });
  } else locationText = 'Geolocation not supported';

  function updateTicker() {
    var now = new Date();
    $('#tickerText').html(
      '<i class="bi bi-calendar3 me-1"></i> ' + now.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) +
      ' &nbsp;&bull;&nbsp; <i class="bi bi-clock me-1"></i> ' + now.toLocaleTimeString() +
      ' &nbsp;&bull;&nbsp; <i class="bi bi-geo-alt me-1"></i> ' + esc(locationText) +
      ' &nbsp;&bull;&nbsp; Bakerz Bite — Where smiles are served daily! &nbsp;&bull;&nbsp; 20% OFF Morning Combo with code MORNING20 &nbsp;&bull;&nbsp; New here? Use BITE10 for 10% off'
    );
  }
  updateTicker(); setInterval(updateTicker, 1000);
});
